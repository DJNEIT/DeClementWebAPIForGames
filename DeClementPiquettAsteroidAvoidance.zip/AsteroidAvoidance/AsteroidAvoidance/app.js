const express = require("express"); 
const app = express(); 
const PORT = 5000; 
const path = require("path");
app.get("/", (req, res) => { res.send("Express server is running!"); });
 app.listen(PORT, () => { console.log(`Server listening on port ${PORT}`); });


app.use(express.static(path.join(__dirname,"public")));

app.use(express.json());

 app.get("/main", (req,res)=>{
    res.sendFile(path.join(__dirname, "public", "index.html"));
});
 