const express = require("express"); 
const app = express(); 
const PORT = 5000; 
require("dotenv").config();
const mongoose = require("mongoose");
const path = require("path");
const fs = require("fs");
const MONGO_URI = process.env.MONGO_URI;


const gameSchema = new mongoose.Schema({},{strict:false});
const VideoGameData = mongoose.model("midtermgroup", gameSchema);

async function connectToMongo()
{
    try {
        // await mongoose.connect(MONGO_URI);
        await mongoose.connect("mongodb+srv://TytansDeath:NOO14c7OtwlyHay8@cluster0.hcbnncz.mongodb.net/VideoGameDataBase?appName=Cluster0");
        console.log("Connected to Database");
    } catch (error) {
        console.error("MongoDB connection error ", error.message);
        process.exit(1);
    }
}

app.get("/", (req, res) => { res.send("Express server is running!"); });
//  app.listen(PORT, () => { console.log(`Server listening on port ${PORT}`); });


app.use(express.static(path.join(__dirname,"public")));

app.use(express.json());

 app.get("/main", (req,res)=>{
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.get("/highscores", async (req,res)=>{
    const games = await VideoGameData.find();
    console.log(games + "   dgojr");
    res.json(games);
});
connectToMongo().then(()=>{
    app.listen(PORT, ()=>{
    console.log(`Server is running on ${PORT}`);
    });
})
 