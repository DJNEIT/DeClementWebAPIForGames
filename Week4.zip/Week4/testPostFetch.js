fetch("/api/highscores",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({playerName:"Jordan",score:1000,level:3})
})