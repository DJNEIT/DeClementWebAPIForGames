const express = require("express");
const HighScore = require("../models/HighScore");
const requireAuth = require("../middleware/requireAuth");

const router = express.Router();

//Anything which uses woer requires the authentication
router.use(requireAuth);

//Posst route for adding player scores
router.post("/", async (req,res)=>{
    try{
        console.log("userId");
        const userId = req.user.sub;
        const{playerName, score,level} = req.body;
        console.log(userId);
        const createdScore = await HighScore.create({userId, playerName,score,level});

        res.status(201).json({ok:true, createdScore});
    }
    catch(err){
        res.status(400).json({ok:false,error:"Invalid Highscore"});
    }
});

//get route for requesting data
router.get("/", async (req,res)=>{
    try{
        const userId = req.user.sub;
        const scores = await HighScore.find({userId})
        .sort({score:-1,createdAt:1})
        .limit(10);
        res.json(scores);
    }catch(err){
        res.status(500).json({ok:false, error:"Failed to fetch High Scores"});
    }
});


//Delete Route
router.delete("/:id", async (req,res)=>{
    console.log(req.params);
    try{
        const userId = req.user.sub;
        const {id} = req.params;
        console.log(id,userId);
        const deleted = await HighScore.findByIdAndDelete({_id:id,userId});
        if(!deleted)
        {
            return res.status(404).json({ok:false, error:"Score not found"});
        }
        res.json({ok:true, deletedId: id});

    }
    catch(err){
        res.status(400).json({ok:false, error:"Delete Failed"});
    }
});

router.get("/:id", async (req,res)=>{
    try{
        const score = await HighScore.findById(req.params.id);

        if(!score)
        {
            return res.status(404).json({ok:false, error:"Not found"});
        }
        res.json(score);
    }
    catch(err)
    {
        
            return res.status(400).json({ok:false, error:"Invalid ID"});
    }
});

router.put("/:id", async(req,res)=>{
    console.log(req.params);
    try{
        
        const userId = req.user.sub;
        //Update HighSCore
        const {id} = req.params;

        //only llow expected fields
        const payload = {};
        if(typeof req.body.playerName === "string")
        {
            payload.playerName = req.body.playerName;
        }

        if(typeof req.body.score === "number")
        {
            payload.score = req.body.score;
        }
        if(typeof req.body.level === "number")
        {
            payload.level = req.body.level;
        }

        const updatedEntry = await HighScore.findByIdAndUpdate({_id:id, userId}, payload, {
            new:true,
            runValidators:true
        });

        if(!updatedEntry)
        {
            return res.status(404).json({ok:false, error:"Score entry not found"});
        }
        res.json({ok:true, updatedEntry});
    }catch(err)
    {
            return res.status(400).json({ok:false, error:"Update failed"});
    }
});
module.exports = router;
