const scoreList = document.getElementById("scoreList");
const statusDisplay = document.getElementById("status");
const form = document.getElementById("scoreForm");
const token = localStorage.getItem("token");
if(!token)
{
    window.location.href = "/login.html";
}
function authHeaders(){
    return {
        "Content-Type":"application/json",
        "Authorization": "Bearer " + token
    }
}

async function loadScores(){
    scoreList.innerHTML = "";
    statusDisplay.textContent = "Loading Scores...";

    try{
        // console.log(token);
        const res = await fetch("/api/highscores", {headers:{"Authorization": `Bearer ${token}`}});
        if(res.status === 401){
            localStorage.removeItem("token");
             window.location.href = "/login.html";
             return;
        }

        const scores = await res.json();

        if(scores.length === 0){
            statusDisplay.textContent = "No scores available";
            return;
        }

        scores.forEach(score => {
            const li = document.createElement("li");
            const deleteBtn = document.createElement("button");
            deleteBtn.textContent = "Delete";
            deleteBtn.type = "button";


            const editBtn = document.createElement("button");
            editBtn.textContent = "Edit";
            editBtn.type = "button";

            
            //Add Button call
            deleteBtn.addEventListener("click",async ()=>{
                if(!confirm(`Delete ${score.playerName}'s score`))
                {
                    return;
                }
                await deleteScore(score._id);
                loadScores();
            })
             editBtn.addEventListener("click",async ()=>{
                window.location.href = `/edit.html?id=${encodeURIComponent(score._id)}`;
            })
            li.textContent = `${score.playerName}    `;
            // li.textContent = `${score.playerName} - ${score.score} - ${score.level}     `;
            li.appendChild(deleteBtn);
            li.appendChild(editBtn);
            scoreList.appendChild(li);
        });

        statusDisplay.textContent=` Loaded ${scores.length} scores.`
    }
    catch(err){
        statusDisplay.textContent = "Failed to load Scores"
    }
}

form.addEventListener("submit", async (e)=>{
    e.preventDefault();

    const playerName = document.getElementById("playername").value;
    const score = document.getElementById("score").value;
    const level = document.getElementById("level").value;

    statusDisplay.textContent = "Submitting new score...";
    console.log("ye scuck");
    try{
        await fetch("/api/highscores", {
            method:"POST",
            //headers:{"Content-Type":"application/json"},
            headers:authHeaders(),            
            body:JSON.stringify({playerName,score,level})

        });
        console.log("please");
        form.reset();
        loadScores();
    }
    catch(err){
        statusDisplay.textContent = "Failed to submit score"
    }
});

async function deleteScore(id)
{
    statusDisplay.textContent = "Delete...";

    const res = await fetch(`/api/highscores/${id}`, {
        method:"DELETE",
        headers:{"Authorization":`Bearer ${token}`}
    });

    if(!res.ok)
    {
        statusDisplay.textContent = "Delete Failed";
    }
    else{
        
    statusDisplay.textContent = "Score Deleted";
    }
}

document.getElementById("logoutBtn").addEventListener("click", ()=>{
    localStorage.removeItem("token");
    window.location.href = "/login.html";
})
loadScores();