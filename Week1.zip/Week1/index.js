const express = require("express"); 
const fs = require("fs");
const path = require("path");
const app = express(); 
const PORT = 5000; 


//Static route set Up
app.use(express.static(path.join(__dirname,"public")));
app.use(express.json());

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "signInPage.html"));
});

app.get("/main", (req,res)=>{
    res.sendFile(path.join(__dirname, "public", "signInPage.html"));
});
app.get("/secondPage", (req,res)=>{
    res.sendFile(path.join(__dirname, "public", "secondPage.html"));
});

app.get("/api/games", (req,res)=>{
    fs.readFile("games.json", "utf-8", (err,data)=>{
        if(err)
        {
            res.status(500).json({error:"Failed to read data file"});
            return;
        }
        //send actual data
        res.json(JSON.parse(data));
    });
});
app.listen(PORT, () => { console.log(`Server listening on port ${PORT}`); });