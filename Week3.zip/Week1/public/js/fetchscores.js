const scoreList = document.getElementById("scoreList");
const statusDisplay = document.getElementById("status");
const form = document.getElementById("scoreForm");

async function loadScores(){
    scoreList.innerHTML = "";
    statusDisplay.textContent = "Loading Scores...";

    // try{
    //     const scores = await res.json();

    //     if(scores.length === 0){
    //         statusDisplay.textContent = "No scores available";
    //         return;
    //     }

    //     scores.forEach(score => {
    //         const li = document.createElement("li");
    //         const deleteBtn = document.createElement("button");
    //         deleteBtn.textContent = "Delete";
    //         deleteBtn.type = "button";


    //         const editBtn = document.createElement("button");
    //         editBtn.textContent = "Edit";
    //         editBtn.type = "button";

            
    //         //Add Button call
    //         deleteBtn.addEventListener("click",async ()=>{
    //             if(!confirm(`Delete ${score.playerName}'s score`))
    //             {
    //                 return;
    //             }
    //             await deleteScore(score._id);
    //             loadScores();
    //         })
    //          editBtn.addEventListener("click",async ()=>{
    //             window.location.href = `/edit.html?id=${encodeURIComponent(score._id)}`;
    //         })
    //         li.textContent = `${score.playerName} - ${score.score} - ${score.level}     `;
    //         li.appendChild(deleteBtn);
    //         li.appendChild(editBtn);
    //         scoreList.appendChild(li);
    //     });

    //     statusDisplay.textContent=` Loaded ${scores.length} scores.`
    // }
    // catch(err){
    //     statusDisplay.textContent = "Failed to load Scores"
    // }
}

form.addEventListener("submit", async (e)=>{
    // e.preventDefault();

    const gameName = document.getElementById("gamename").value;
    // const score = document.getElementById("score").value;
    // const level = document.getElementById("level").value;

    statusDisplay.textContent = "Submitting new score...";
    console.log("ye scuck");
    try{
        await fetch("/api/highscores", {
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({gamename})
        });
        console.log("please");
        form.reset();
        loadScores();
    }
    catch(err){
        statusDisplay.textContent = "you to submit score"
        console.log("please");
    }
});

// async function deleteScore(id)
// {
//     statusDisplay.textContent = "Delete...";

//     const res = await fetch(`/api/highscores/${id}`, {method:"DELETE"});
//     if(!res.ok)
//     {
//         statusDisplay.textContent = "Delete Failed";
//     }
//     else{
        
//     statusDisplay.textContent = "Score Deleted";
//     }
// }
loadScores();