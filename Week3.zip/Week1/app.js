const express = require("express"); 
const fs = require("fs");
const path = require("path");
require("dotenv").config();
const mongoose = require("mongoose");
const app = express(); 
const PORT = process.env.PORT||5000; 
const MONGO_URI = process.env.MONGO_URI;


//Static route set Up
app.use(express.static(path.join(__dirname,"public")));
app.use(express.json());

if(!MONGO_URI)
{
    console.error("Missing DataBase Connection");
    process.exit(1);
}
async function connectToMongo()
{
    try {
        await mongoose.connect(MONGO_URI);
        console.log("Connected to Database");
    } catch (error) {
        console.error("MongoDB connection error ", error.message);
        process.exit(1);
    }
}

app.get("/", (req, res) => {
    
    console.log("Hallo");
    res.sendFile(path.join(__dirname, "public", "signInPage.html"));
});

app.get("/main", (req,res)=>{
    res.sendFile(path.join(__dirname, "public", "signInPage.html"));
});
// app.get("/secondPage", (req,res)=>{
//     res.sendFile(path.join(__dirname, "public", "secondPage.html"));
// });

app.get("/api/games", (req,res)=>{
    fs.readFile("games.json", "utf-8", (err,data)=>{
        if(err)
        {
            res.status(500).json({error:"Failed to read data file"});
            return;
        }
        //send actual data
        res.json(JSON.parse(data));
    });
});
connectToMongo().then(()=>{
    app.listen(PORT, ()=>{
    console.log(`Server is running on ${PORT}`);
    });
})
// app.listen(PORT, () => { console.log(`Server listening on port ${PORT}`); });
//